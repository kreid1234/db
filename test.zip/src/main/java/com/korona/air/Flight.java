package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.persistence.Column;
import javax.persistence.Entity;
import java.text.ParseException;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "FLIGHT")
@Getter @Setter
public class Flight implements java.io.Serializable {
    @Id
    private String partial_name;
    @Column(name = "AIRPORT_NAME")
    private String airport_name;
    
    @Temporal(TemporalType.TIME)
    @Column(name = "DATE_TIME")
    private Date datetime;

    @Temporal(TemporalType.DATE)
    @Column(name = "DAY")
    private Date ymd;

    @Column(name = "FLIGHT_DISTANCE")
    private String flightdistance;
    @Column(name = "GATE_ENUMBER")
    private Integer gatenumber;

    @Column(name = "BOARDING_STATUS")
    private Integer boarding_status;

    @Column(name = "DESTINATION")
    private String destination;

    @ManyToOne( fetch=FetchType.LAZY)
    @JoinColumn(name = "AIRPLANE_ID")
    private Airplane airplane_id;

    @OneToMany(mappedBy = "partial_name",  fetch=FetchType.LAZY)
    private Set<ReservationInfo> reservation_id = new HashSet<ReservationInfo>(0);

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "AIRPLANEOFFICE_ID")
    private Airplaneoffice airplaneoffice_id;
    public Flight(){

    }
    public Flight(String partial_name, String datetime,String distance,int gatenum, String des, int boarding_status, String day){
        this.partial_name = partial_name;
        this.airport_name = "Donkey";
        SimpleDateFormat transFormat = new SimpleDateFormat("HH:mm");
        try{
            Date to = transFormat.parse(datetime);
            this.datetime = to;
        }catch(ParseException e){
            System.out.println(e.getMessage());
        }
        this.flightdistance = distance;
        this.gatenumber = gatenum;
        this.destination = des;
        this.boarding_status = boarding_status;
        SimpleDateFormat transFormat2 = new SimpleDateFormat("yyyy-MM-dd");
        try{
            Date to2 = transFormat2.parse(day);
            this.ymd = to2;
        }catch(ParseException e){
            System.out.println(e.getMessage());
        }

    }

    @Override
    public boolean equals(Object obj) {
        Flight f = (Flight) obj;
        return partial_name.equals(f.getPartial_name());
    }
}


