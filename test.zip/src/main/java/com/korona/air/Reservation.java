package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;


@Entity
@Table(name = "RESERVATION")
@Getter @Setter
public class Reservation implements java.io.Serializable {
    @EmbeddedId 
    private CustomerReservationId id = new CustomerReservationId();

    @ManyToOne (fetch=FetchType.LAZY , cascade={CascadeType.ALL})
    @MapsId("info_id") 
    private ReservationInfo Reservation;

    @ManyToOne (fetch=FetchType.LAZY, cascade={CascadeType.ALL})
    @MapsId("customer_id") 
    private Customer Customer;

    @ManyToOne (fetch=FetchType.LAZY, cascade={CascadeType.ALL})
    @MapsId("price_id") 
    private Flightprice Flightprice;

    @ManyToOne(fetch=FetchType.LAZY)
    @MapsId("airplaneoffice_id")
    private Airplaneoffice Airplaneoffice;

    @Column(name = "Price")
    private Integer price;

}