package com.korona.air;

import javax.persistence.*;

@Embeddable
class CustomerReservationId implements java.io.Serializable {
    @Column(name="Reservation_infoId") Integer info_id;
    @Column(name="Customer_id") Integer customer_id;
    @Column(name="Price_id") Integer price_id;
    @Column(name="Airplaneoffice_id") Integer airplaneoffice_id;

}