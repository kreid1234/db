package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "FLIGHTPRICE")
@Getter @Setter
public class Flightprice implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = AUTO)
    @Column(name = "PRICE_ID", nullable = false)
    private Integer Price_id;
    @Column(name = "SEAT_CLASS")
    private Integer seatclass;
    @Column(name = "ADULT")
    private Integer adult;
    @Column(name = "INFANT")
    private Integer infant;
    @Column(name = "CHILD")
    private Integer child;
    @Column(name = "DESTINATION")
    private String destination;

    @OneToMany(mappedBy = "Flightprice", 
    cascade = CascadeType.ALL, orphanRemoval = true, fetch=FetchType.LAZY)
    Set<Reservation> Reservation_id = new HashSet<Reservation>(0);

    public Flightprice(){

    }
    public Flightprice(Integer seatclass, Integer adult, Integer infant, Integer child){
        this.seatclass = seatclass;
        this.adult = adult;
        this.infant  = infant;
        this.child = child;
    }

    public int PriceCommit(){
        int price = this.adult * 150000;
        price += this.infant * 50000;
        price += this.child * 100000;
        price *= this.seatclass;
        return price;
    }

}


