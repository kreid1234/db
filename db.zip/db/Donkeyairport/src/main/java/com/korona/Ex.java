package com.korona;

import static spark.Spark.*;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import java.lang.Integer;
import java.util.Calendar;
import com.korona.air.*;
import java.text.ParseException;
import java.util.TimeZone;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.hibernate.SessionFactory;
import org.hibernate.Query;
import org.hibernate.cfg.Configuration;
import javax.persistence.EntityManager;
import javax.servlet.MultipartConfigElement;
import java.util.List;
import com.korona.util.HibernateUtil;
import org.hibernate.Session;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class Ex {
    final static String Apath = "/home/ubunt/db/Donkeyairport";
    public static void main(String[] argv) {
        staticFiles.location("/public");
        System.out.println(Ex.class.getResource(".").getPath());
        
        Airplaneoffice office = new Airplaneoffice("Donkey");
        
        airPlaneFactory(office);
        post("/reservation", (req, res) -> {
            
            String htmlS = "";
            String line = "";
            String date = req.queryParams("date");
            String src_time = req.queryParams("time");
            String dst_time = req.queryParams("time2");
            String destination = req.queryParams("destination");
            String plane_code = req.queryParams("AIRPLANE");
            String office_name = req.queryParams("office");
            Integer adult = Integer.parseInt(req.queryParams("adult"));
            Integer Infant = Integer.parseInt(req.queryParams("Infant"));
            Integer child = Integer.parseInt(req.queryParams("child"));
            Integer seat_rate = Integer.parseInt(req.queryParams("rate"));
            Session session = HibernateUtil.getSessionFactory().openSession();
            String cookie_dst;
            res.cookie("adult",req.queryParams("adult"));
            res.cookie("Infant", req.queryParams("Infant"));
            res.cookie("child", req.queryParams("child"));
            res.cookie("seat_rate",req.queryParams("rate"));
          
            
            String table = "";
            if( !plane_code.equals("nodata") ){
                //편명으로 검색하기
                
                try {
                    Query query = session.createQuery("from Flight WHERE partial_name = :plan");
                    query.setParameter("plan", plane_code);
                    
                    List<Flight> flight = query.list();
                     if(flight.size() == 0){
                    BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/notfound.html")));
                    while((line = br.readLine()) != null){
                        htmlS += line;
                    }
                    br.close();
                    return htmlS;
                }
                    if(flight.size() != 0){
                            
                        table = "<table border=\"0\">" + "<thead> <tr><th>항공사</th><th>운항편명</th><th>예정시각</th><th>비행예상시간</th><th>목적지</th><th>총 좌석</th><th>탑승현황</th><th>항공기명</th></tr> <thead> <tbody class = \"tables\">";
                        for (Flight task : flight) {
                            SimpleDateFormat transFormats = new SimpleDateFormat("HH:mm");
                            String to = transFormats.format(task.getDatetime());
                            table += "<tr><td>" + task.getPartial_name() + "</td><td>" + task.getAirplaneoffice_id().getAirplane_office_name() + "</td><td>" + to + "</td><td>" + task.getFlightdistance() + "</td><td>" + task.getDestination() + "</td><td>" + task.getAirplane_id().getMax_plane_seat() + "</td><td>" + task.getBoarding_status() + "</td><td>" + task.getAirplane_id().getName() + "</td></tr>\n";
                        }
                        table += "</tbody></table>";
                    }
                    
                }catch (Exception e) {
                    e.printStackTrace();
                    session.close();
                    return "Error: " + e.getMessage();
                }
                try{
                    BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/Reservation2.html")));
                    while((line = br.readLine()) != null){
                        htmlS += line;
                    }
                    br.close();
                    htmlS += table;
                    BufferedReader br3 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/Reservation2_tail.html")));
                    while((line = br3.readLine()) != null){
                        htmlS += line;
                    }
                    br3.close();

                    }catch(IOException e){
                        e.printStackTrace();
                        session.close();
                        return e.getMessage();
                    }
                
                    

                    if (session.isOpen()) {
                        session.close();
                    }
                    return htmlS;
            }
            try{
            //편명이 아닐때
                Query query3 = session.createQuery("from Flight WHERE ymd = CAST(? AS date) AND date_time >= CAST(? AS time) AND date_time <= CAST(? AS time) AND airport_name = ? AND destination = ?");
                SimpleDateFormat transFormat = new SimpleDateFormat("HH:mm");
                query3.setParameter(0, date);
                query3.setParameter(1, src_time);
                query3.setParameter(2, dst_time);
                query3.setParameter(3, office_name);
                query3.setParameter(4, destination);

                List<Flight> flight = query3.list();
                if(flight.size() == 0){
                    BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/notfound.html")));
                    while((line = br.readLine()) != null){
                        htmlS += line;
                    }
                    br.close();
                    return htmlS;
                }

                table = "<table border=\"0\">" + "<thead> <tr><th>운항편명</th><th>항공사</th><th>예정시각</th><th>비행예상시간</th><th>목적지</th><th>총 좌석</th><th>탑승현황</th><th>항공기명</th></tr> <thead> <tbody class = \"tables\">";
                
                for (Flight task : flight) {
                            SimpleDateFormat transFormats = new SimpleDateFormat("HH:mm");
                            String to = transFormats.format(task.getDatetime());
                            table += "<tr><td>" + task.getPartial_name() + "</td><td>" + task.getAirplaneoffice_id().getAirplane_office_name() + "</td><td>" + to + "</td><td>" + task.getFlightdistance() + "</td><td>" + task.getDestination() + "</td><td>" + task.getAirplane_id().getMax_plane_seat() + "</td><td>" + task.getBoarding_status() + "</td><td>" + task.getAirplane_id().getName() + "</td></tr>\n";
                }
                table += "</tbody></table>";
            }catch (Exception e) {
                e.printStackTrace();
                session.close();
                return "Error: " + e.getMessage();
            }
            //html reservation 2 return
            try{
                BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/Reservation2.html")));
                while((line = br.readLine()) != null){
                    htmlS += line;
                }
                br.close();
                htmlS += table;
                BufferedReader br3 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/Reservation2_tail.html")));
                while((line = br3.readLine()) != null){
                    htmlS += line;
                }
                br3.close();

            }catch(IOException e){
                e.printStackTrace();
                session.close();
                return e.getMessage();
            }
          
            if (session.isOpen()) {
                session.close();
            }
            return htmlS;
        });

        post("/airSelect", (req,res)->{
            String htmlS = "";
            String line;
            String num = req.queryParams("num");
            res.cookie("num",num);

            //html reservation 3 return
            try{
                BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/Reservation3.html")));
                while((line = br.readLine()) != null){
                    htmlS += line;
                }
                br.close();
            }catch(IOException e){
                e.printStackTrace();
                return e.getMessage();
            }
            return htmlS;
        });

        post("/airSelect2", (req,res)->{
            String htmlS = "";
            String line;
            String table;
            String Firstname = req.queryParams("Firstname");
            String Lastname = req.queryParams("Lastname");
            String UserRate = req.queryParams("user-rate");
            String Address = req.queryParams("address");
            String pNum = req.queryParams("p1") + "-" + req.queryParams("p2");
            String Pass = req.queryParams("pass");
            String partial_name = req.cookie("num");

            Integer seat_rate = Integer.parseInt(req.cookie("seat_rate"));
            Integer child = Integer.parseInt(req.cookie("child"));
            Integer Infant = Integer.parseInt(req.cookie("Infant"));
            Integer adult = Integer.parseInt(req.cookie("adult"));
            res.cookie("adult", adult.toString());
            res.cookie("Infant", Infant.toString());
            res.cookie("child", child.toString());
            res.cookie("seat_rate",seat_rate.toString());
            res.cookie("Firstname", Firstname);
            res.cookie("Lastname", Lastname);
            res.cookie("user-rate", UserRate);
            res.cookie("address", Address);
            res.cookie("p1p2", pNum);
            res.cookie("pass", Pass);
            res.cookie("num", partial_name);


            Session session = HibernateUtil.getSessionFactory().openSession();
             //session.getTransaction().begin();
            //public Customer(String password, String name, String rate, String address, String rrnum){
            //seat capacuty
            Customer cus = new Customer(Pass, Firstname+Lastname, UserRate, Address, pNum);

            ReservationInfo reserInfo = new ReservationInfo(child + Infant + adult);
            
            Query query = session.createQuery("from ReservationInfo where partial_name = ?"); 
            Flight flight = (Flight) session.load(Flight.class, partial_name);
            query.setParameter(0, flight);   
            List<ReservationInfo> reserList = query.list();
            if(reserList.size() != 0){
                int i = 0;
                for(;i < reserList.get(0).getAirplane_id().getMax_plane_seat(); i++){
                    for(ReservationInfo task : reserList){
                        if(task.getSeat_number() == i){
                            continue;
                        }
                    }
                    reserInfo.setSeat_number(i);
                    break;
                }
            }else{
                reserInfo.setSeat_number(0);
            }
            reserInfo.setAirplane_id(flight.getAirplane_id());
            reserInfo.setPartial_name(flight);
            //------Customer_Reservation-----------
            Reservation res_cus = new Reservation();
            res_cus.setAirplaneoffice(flight.getAirplaneoffice_id());
            
            //res_cus.setReservation(reserInfo);
            //res_cus.setCustomer(cus);
            //cus.getReservation_info().add(res_cus);
            //reserInfo.getCustomer().add(res_cus);

            //세션저장, 해쉬값일 경우 중복되면 원래 객체로 업데이트 되는지 알기.
            //public Flightprice(String seatclass, Integer adult, Integer infant, Integer child){
            Flightprice fp = new Flightprice(seat_rate, adult, Infant, child);
            fp.setDestination(flight.getDestination());
            res_cus.setFlightprice(fp);
            res_cus.setReservation(reserInfo);
            res_cus.setAirplaneoffice(flight.getAirplaneoffice_id());
            res_cus.setCustomer(cus);
            //session.persist(fp);

            //session.getTransaction().commit();
            int price = fp.PriceCommit();
            price = price / Integer.parseInt(UserRate);
            res_cus.setPrice(price);
            //session.persist(res_cus);
            //price : 계산서 값
            if (session.isOpen()) { 
                session.close();
            }

            //html 계산서 4 return
            try{
                BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/bill.html")));
                while((line = br.readLine()) != null){
                    htmlS += line;
                }
                br.close();
                table = " <br><br><h3>" + "Name : " + Firstname + Lastname + "</h3><br><h3>" + "PNUM : " + req.queryParams("p1") + "- *******" + "&nbsp&nbsp&nbsp&nbsp" + "Partial Code : " +partial_name+ "</h3><br><h3>" + "Destination : " + flight.getDestination() + "</h3><br><h2 style=\"color:#069\">" + "Price : " + price + "$"+"</h2>" ;
                htmlS += table;
                BufferedReader br2 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/bill2.html")));
                while((line = br2.readLine()) != null){
                    htmlS += line;
                }
                br2.close();
            }catch(IOException e){
                e.printStackTrace();
                session.close();
                return e.getMessage();
            }
            if (session.isOpen()) { 
                session.flush();
                session.close();
            }
            return htmlS;
        });     //fake page..

        post("/delProfile", (req, res) -> {

            String userName = req.queryParams("num");
            String partialCode = req.queryParams("num2");
            String seatNum = req.queryParams("num3");
            Integer allCapa = Integer.parseInt(req.queryParams("num4"));
            Session session = HibernateUtil.getSessionFactory().openSession();

            Query query = session.createQuery("from ReservationInfo WHERE partial_name = ? AND seat_number = ? AND seatingcapacity = ?");
            Flight flight = (Flight) session.load(Flight.class, partialCode);
            query.setParameter(0, flight);  
            int a = seatNum.indexOf('(');
            Integer tempSeat =  Integer.parseInt(seatNum.substring(2,a));
            query.setParameter(1, tempSeat);
            query.setParameter(2, allCapa);
            List<ReservationInfo> reservationList = query.list();
            if(reservationList.size() == 0){
                return "예기치 못한 접근.";  
            }else{
                session.getTransaction().begin();
                for(ReservationInfo task : reservationList){
                    Query query4 = session.createQuery("from Reservation WHERE Reservation = ?");
                    query4.setParameter(0, task);
                    List<Reservation> reservations = query4.list();
                    for(Reservation reservation : reservations){
                        session.delete(reservation);
                    }
                    //session.delete(task);
                }
            }
            flight.setBoarding_status(flight.getBoarding_status() - allCapa);
            session.update(flight);
            session.getTransaction().commit();
            //-------------------------------------------------
            String htmlS = "";
            String line;
            String table;
            String pNum = req.cookie("pNum");
            String Pass = req.cookie("Pass");
            res.cookie("pNum", pNum);
            res.cookie("Pass", Pass);
            try{
                Query query2 = session.createQuery("from Customer WHERE rrnum = ? AND password = ?");
                query2.setParameter(0, pNum);
                query2.setParameter(1, Pass);
                List<Customer> cus_s = query2.list();


                table = "<table border=\"0\">" + "<thead> <tr><th>이름</th><th>편명</th><th>목적지</th><th>가격</th><th>좌석번호</th><th>총 예약인원</th></tr> <thead> <tbody class = \"tables\">";
                for(Customer task : cus_s){
                        //테이블 뿌려주기
                    Query query3 = session.createQuery("from Reservation WHERE Customer = ?");
                    query3.setParameter(0, task);
                    List<Reservation> task2 = query3.list();
                    for(Reservation re : task2){
                        table += "<tr><td>" + re.getCustomer().getName() + "</td><td>" + re.getReservation().getPartial_name().getPartial_name() + "</td><td>" + re.getReservation().getPartial_name().getDestination() + "</td><td>" + re.getPrice() + "</td><td>" +  re.getFlightprice().getSeatclass()+"C"+re.getReservation().getSeat_number() + "("+"Line--" + ")"+"</td><td>"  + re.getReservation().getSeatingcapacity() + "</td></tr>\n";
                    }
                }
                 table += "</tbody></table>";
            

            BufferedReader br2 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/profile2.html")));
            while((line = br2.readLine()) != null){
                htmlS += line;
            }
            br2.close();
            htmlS += table;
            BufferedReader br3 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/profile2t.html")));
            while((line = br3.readLine()) != null){
                htmlS += line;
            }
            br3.close();
            }catch(Exception e){
                e.printStackTrace();
                if (session.isOpen()) { 
                    session.close();
                }
                return e.getMessage();
            }
            if(session.isOpen()){
                session.close();
            }
            return htmlS;

            
        });


        post("/profile" ,(req, res) ->{
            String htmlS = "";
            String line;
            String table;
            String pNum = req.queryParams("p1") + "-" + req.queryParams("p2");
            String Pass = req.queryParams("pass");
            Session session = HibernateUtil.getSessionFactory().openSession();
            res.cookie("pNum", pNum);
            res.cookie("Pass", Pass);
            try{
                Query query = session.createQuery("from Customer WHERE rrnum = ? AND password = ?");
                query.setParameter(0, pNum);
                query.setParameter(1, Pass);
                List<Customer> cus_s = query.list();
                if(cus_s.size() == 0){
                    BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/notfound3.html")));
                    while((line = br.readLine()) != null){
                        htmlS += line;
                    }
                    br.close();
                    return htmlS;   
                }


                table = "<table border=\"0\">" + "<thead> <tr><th>이름</th><th>편명</th><th>목적지</th><th>가격</th><th>좌석번호</th><th>총 예약인원</th></tr> <thead> <tbody class = \"tables\">";
                for(Customer task : cus_s){
                        //테이블 뿌려주기
                    Query query2 = session.createQuery("from Reservation WHERE Customer = ?");
                    query2.setParameter(0, task);
                    List<Reservation> task2 = query2.list();
                    for(Reservation re : task2){
                        table += "<tr><td>" + re.getCustomer().getName() + "</td><td>" + re.getReservation().getPartial_name().getPartial_name() + "</td><td>" + re.getReservation().getPartial_name().getDestination() + "</td><td>" + re.getPrice() + "</td><td>" +  re.getFlightprice().getSeatclass()+"C"+re.getReservation().getSeat_number() + "("+"Line--" + ")"+"</td><td>"  + re.getReservation().getSeatingcapacity() + "</td></tr>\n";
                    }
                }
                 table += "</tbody></table>";
            

            BufferedReader br2 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/profile2.html")));
            while((line = br2.readLine()) != null){
                htmlS += line;
            }
            br2.close();
            htmlS += table;
            BufferedReader br3 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/profile2t.html")));
            while((line = br3.readLine()) != null){
                htmlS += line;
            }
            br3.close();
            }catch(Exception e){
                e.printStackTrace();
                if (session.isOpen()) { 
                    session.close();
                }
                return e.getMessage();
            }
            if(session.isOpen()){
                session.close();
            }
            return htmlS;

        });

        post("/lookup2" ,(req, res) ->{
            Session session = HibernateUtil.getSessionFactory().openSession();
            String table = "";
            String htmlS = "";
            String date = req.queryParams("date");
            String line;
            
            
                try {
                    Query query = session.createQuery("from Flight WHERE day = CAST(:plan AS date)");
                    query.setParameter("plan", date);

                    List<Flight> flight = query.list();
                     if(flight.size() == 0){
                    BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/notfound.html")));
                    while((line = br.readLine()) != null){
                        htmlS += line;
                    }
                    br.close();
                    return htmlS;
                }
                    if(flight.size() != 0){
                            
                        table = "<table border=\"0\">" + "<thead> <tr><th>운항편명</th><th>항공사</th><th>예정시각</th><th>비행예상시간</th><th>목적지</th><th>총 좌석</th><th>탑승현황</th><th>항공기명</th></tr> <thead> <tbody class = \"tables\">";
                        for (Flight task : flight) {
                            SimpleDateFormat transFormats = new SimpleDateFormat("HH:mm");
                            String to = transFormats.format(task.getDatetime());
                            table += "<tr><td>" + task.getPartial_name() + "</td><td>" + task.getAirplaneoffice_id().getAirplane_office_name() + "</td><td>" + to + "</td><td>" + task.getFlightdistance() + "</td><td>" + task.getDestination() + "</td><td>" + task.getAirplane_id().getMax_plane_seat() + "</td><td>" + task.getBoarding_status() + "</td><td>" + task.getAirplane_id().getName() + "</td></tr>\n";
                        }
                        table += "</tbody></table>";
                    }
                BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/lookup_rout.html")));
                while((line = br.readLine()) != null){
                    htmlS += line;
                }
                br.close();
                htmlS += table;
                BufferedReader br2 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/lookup_t.html")));
                while((line = br2.readLine()) != null){
                    htmlS += line;
                }
                br2.close();
                }catch (Exception e) {
                    e.printStackTrace();
                    if (session.isOpen()) { 
                    session.close();
                    }
                    return "Error: " + e.getMessage();
                }
                if (session.isOpen()) { 
                session.flush();
                session.close();
                }
                return htmlS;
        });

        post("/lookup", (req,res)->{
            Session session = HibernateUtil.getSessionFactory().openSession();
            String table = "";
            String htmlS = "";
            String line;

                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String currentTime = sdf.format(new Date());
                    Calendar c = Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));
                    String fromDate = sdf.format(c.getTime());
                    c.add(Calendar.DATE, 7);
                    String toDate = sdf.format(c.getTime());
                    Query query = session.createQuery("from Flight WHERE day = CAST(:plan AS date)");
                    query.setParameter("plan", toDate);
                    
                    System.out.println("asd2");
                    List<Flight> flight = query.list();
                    if(flight.size() == 0){
                    BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/notfound.html")));
                    while((line = br.readLine()) != null){
                        htmlS += line;
                    }
                    br.close();
                    if(session.isOpen()){
                        session.close();
                    }
                    return htmlS;
                }
                    if(flight.size() != 0){
                            
                        table = "<table border=\"0\">" + "<thead> <tr><th>항공사</th><th>운항편명</th><th>예정시각</th><th>비행예상시간</th><th>목적지</th><th>총 좌석</th><th>탑승현황</th><th>항공기명</th></tr> <thead> <tbody class = \"tables\">";
                        for (Flight task : flight) {
                            SimpleDateFormat transFormats = new SimpleDateFormat("HH:mm");
                            String to = transFormats.format(task.getDatetime());
                            table += "<tr><td>" + task.getPartial_name() + "</td><td>" + task.getAirplaneoffice_id().getAirplane_office_name() + "</td><td>" + to + "</td><td>" + task.getFlightdistance() + "</td><td>" + task.getDestination() + "</td><td>" + task.getAirplane_id().getMax_plane_seat() + "</td><td>" + task.getBoarding_status() + "</td><td>" + task.getAirplane_id().getName() + "</td></tr>\n";
                        }
                        table += "</tbody></table>";
                    }
                BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/lookup_rout.html")));
                while((line = br.readLine()) != null){
                    htmlS += line;
                }
                br.close();
                htmlS += table;
                BufferedReader br2 = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/lookup_t.html")));
                while((line = br2.readLine()) != null){
                    htmlS += line;
                }
                br2.close();
                }catch (Exception e) {
                    e.printStackTrace();
                    if (session.isOpen()) { 
                    session.close();
                    }
                    return "Error: " + e.getMessage();
                }
                if (session.isOpen()) { 
                session.flush();
                session.close();
                }
                return htmlS;
        });

        post("/lastSelect", (req,res)->{
            String htmlS = "";
            String line;
            String Firstname = req.cookie("Firstname"); 
            String Lastname = req.cookie("Lastname");
            String UserRate = req.cookie("user-rate");
            String Address = req.cookie("address");
            String pNum = req.cookie("p1p2");
            String Pass = req.cookie("pass");
            String partial_name = req.cookie("num");

            Integer seat_rate = Integer.parseInt(req.cookie("seat_rate"));
            Integer child = Integer.parseInt(req.cookie("child"));
            Integer Infant = Integer.parseInt(req.cookie("Infant"));
            Integer adult = Integer.parseInt(req.cookie("adult"));
            
           
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.getTransaction().begin();
            //public Customer(String password, String name, String rate, String address, String rrnum){
            //seat capacuty
            Customer cus = new Customer(Pass, Firstname+Lastname, UserRate, Address, pNum);
            ReservationInfo reserInfo = new ReservationInfo(child + Infant + adult);
            
            Query query = session.createQuery("from ReservationInfo where partial_name = ?"); 

            Flight flight = (Flight) session.get(Flight.class, partial_name);
            query.setParameter(0, flight);
            List<ReservationInfo> reserList = query.list();

            if(reserList.size() != 0){
                    int j  = 0;
                    for(ReservationInfo task : reserList){
                        j += task.getSeatingcapacity();
                    }
                    if(j > flight.getAirplane_id().getMax_plane_seat()){
                        j = flight.getAirplane_id().getMax_plane_seat();
                    }
                    reserInfo.setSeat_number(j);   
            }else{
                reserInfo.setSeat_number(0);
            }

            flight.setBoarding_status( flight.getBoarding_status() + child + Infant + adult);
            session.update(flight);

            reserInfo.setSeatingcapacity(child + Infant + adult);
            reserInfo.setAirplane_id(flight.getAirplane_id());
            reserInfo.setPartial_name(flight);
            //------Customer_Reservation-----------
         
            Reservation res_cus = new Reservation();
            res_cus.setAirplaneoffice(flight.getAirplaneoffice_id());
            
            //res_cus.setReservation(reserInfo);
            //res_cus.setCustomer(cus);
            //cus.getReservation_info().add(res_cus);
            //reserInfo.getCustomer().add(res_cus);

            //세션저장, 해쉬값일 경우 중복되면 원래 객체로 업데이트 되는지 알기.
            //public Flightprice(String seatclass, Integer adult, Integer infant, Integer child){
            Flightprice fp = new Flightprice(seat_rate, adult, Infant, child);
            fp.setDestination(flight.getDestination());
            res_cus.setFlightprice(fp);
            res_cus.setReservation(reserInfo);
            res_cus.setCustomer(cus);

            int price = fp.PriceCommit();
            price = price / Integer.parseInt(UserRate);
            res_cus.setPrice(price);
            session.persist(cus);
            session.persist(fp);
            session.persist(reserInfo);
            session.persist(res_cus);
            
            session.getTransaction().commit();
            //price : 계산서 값
            try{
                BufferedReader br = new BufferedReader( new FileReader (new File(Apath + "/src/main/resources/public/successed.html")));
                while((line = br.readLine()) != null){
                    htmlS += line;
                }
                br.close();
            }catch(IOException e){
                e.printStackTrace();
                if (session.isOpen()) { 
                    session.close();
                }
                return e.getMessage();
            }
            if (session.isOpen()) { 
                session.close();
            }
            
            res.cookie("/", "Firstname", "", 0, false);
            res.cookie("/", "Infant", "", 0, false);
            res.cookie("/", "Lastname", "", 0, false);
            res.cookie("/", "Address", "", 0, false);
            res.cookie("/", "Adult", "", 0, false);
            res.cookie("/", "Child", "", 0, false);
            res.cookie("/", "num", "", 0, false);
            res.cookie("/", "p1p2", "", 0, false);
            res.cookie("/", "seat_rate", "", 0, false);
            res.cookie("/", "pass", "", 0, false);
            res.cookie("/", "user_rate", "", 0, false);
            return htmlS;
        });
    }



    private static void airPlaneFactory(Airplaneoffice office){
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.getTransaction().begin();
        List<Airplane> planes = new ArrayList<Airplane>();

        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 737",160,false));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어버스 A319",120,false));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,false));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 737",160,false));
        planes.add( new Airplane("보잉 737",160,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 800",162,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("보잉 787",160,true));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어버스 A319",120,false));
        planes.add( new Airplane("에어버스 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,true));
        planes.add( new Airplane("에어라인 A319",120,false));
//------------Flight
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        String currentTime = sdf.format(new Date());
        
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));
        
        String fromDate = sdf.format(c.getTime()); 

        List<Flight> f = new ArrayList<Flight>();
        c.add(Calendar.DATE, 7);
        String toDate = sdf.format(c.getTime());
        for(int j = 0; j < 21; j++){
            f.add( new Flight("CAN00" + toDate, "00:00", "3H 55M", 0, "광저우", 0, toDate)); // p1
            f.add( new Flight("CAN06" + toDate, "06:00", "3H 55M", 0, "광저우", 0, toDate)); // p2
            f.add( new Flight("CAN12" + toDate, "12:00", "3H 55M", 0, "광저우", 0, toDate)); // p3
            f.add( new Flight("CAN18" + toDate, "18:00", "3H 55M", 0, "광저우", 0, toDate)); // p6
        
            //----------NRT
            f.add( new Flight("NRT00" + toDate, "00:00", "2H 20M", 1, "도쿄/나리타", 0, toDate)); //p5
            f.add( new Flight("NRT06" + toDate, "06:00", "2H 20M", 1,"도쿄/나리타", 0, toDate)); // p6
            f.add( new Flight("NRT12" + toDate, "12:00", "2H 20M", 1,"도쿄/나리타", 0, toDate)); //p3
            f.add( new Flight("NRT18" + toDate, "18:00", "2H 20M", 1,"도쿄/나리타", 0, toDate)); //p2
            
            //---------HND
            f.add( new Flight("HND00" + toDate, "00:00", "2H 05M", 2, "도쿄/하네다", 0, toDate)); //p7
            f.add( new Flight("HND06" + toDate, "06:00", "2H 05M", 2, "도쿄/하네다", 0, toDate)); //p8
            f.add( new Flight("HND12" + toDate, "12:00", "2H 05M", 2, "도쿄/하네다", 0,toDate)); //p9
            f.add( new Flight("HND18" + toDate, "18:00", "2H 05M", 2, "도쿄/하네다", 0, toDate)); //p10
            
            //-------LAS
            f.add( new Flight("LAS00" + toDate, "00:00", "11H 00M", 3, "라스베이가스", 0, toDate)); //p7
            f.add( new Flight("LAS06" + toDate, "06:00", "11H 00M", 3, "라스베이가스", 0, toDate)); //p8
            f.add( new Flight("LAS12" + toDate, "12:00", "11H 00M", 3, "라스베이가스", 0, toDate)); //p9
            f.add( new Flight("LAS18" + toDate, "18:00", "11H 00M", 3, "라스베이가스", 0, toDate)); //p10
            
            //-------CTS
            f.add( new Flight("CTS00" + toDate, "00:00", "02H 40M", 4, "삿포로", 0, toDate)); //p12
            f.add( new Flight("CTS06" + toDate, "06:00", "02H 40M", 4, "삿포로", 0, toDate)); //p14
            f.add( new Flight("CTS12" + toDate, "12:00", "02H 40M", 4, "삿포로", 0, toDate)); //p15
            f.add( new Flight("CTS18" + toDate, "18:00", "02H 40M", 4, "삿포로", 0, toDate)); //p16
        
            //--------PRG
            f.add( new Flight("PRG00" + toDate, "00:00", "11H 40M", 5, "프라하", 0, toDate)); //p12
            f.add( new Flight("PRG06" + toDate, "06:00", "11H 40M", 5, "프라하", 0, toDate)); //p14
            f.add( new Flight("PRG12" + toDate, "12:00", "11H 40M", 5, "프라하", 0,toDate)); //p15
            f.add( new Flight("PRG18" + toDate, "18:00", "11H 40M", 5, "프라하", 0 ,toDate)); //p16
            c.add(Calendar.DATE, 1);
            toDate = sdf.format(c.getTime());
        }


        int k = 0;
        for(Flight task:f){
            while(!planes.get(k).getAir_Navigation_Status()){
                if(planes.size() <= k+1){
                    k = 0;
                }else{
                    k++;
                }
            }
            task.setAirplane_id(planes.get(k));
            task.setAirplaneoffice_id(office);
            if(planes.size() <= k+1){
                k = 0;
            }
            k++;
        }
        session.persist(office);
        for(Airplane task:planes){
            task.setAirplaneoffice_id(office);
            session.persist(task);
        }
        

        for(Flight task : f){
            session.persist(task);
        }
        session.getTransaction().commit();
        if (session.isOpen()) {
            session.close();
        }
    }
}