package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "AIRPLANE")
@Getter @Setter
public class Airplane implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = AUTO)
    
    @Column(name = "ID", /* unique = true, */ nullable = false)
    private Integer id;
    @Column(name = "NAME")
    private String name;
    @Column(name = "MAXSEAT", nullable = false)
    private Integer max_plane_seat;
    @Column(name = "AIR_NAVIGATION_STATUS")
    private boolean air_Navigation_Status;

    @OneToMany(mappedBy = "airplane_id",  fetch=FetchType.LAZY)
    private Set<Flight> partial_name = new HashSet<Flight>(0);

    @OneToMany(mappedBy = "airplane_id", fetch=FetchType.LAZY)
    private Set<ReservationInfo> Reservationinfo_id = new HashSet<ReservationInfo>(0);

    @ManyToOne( fetch=FetchType.LAZY)
    @JoinColumn(name = "OFFICE_ID")
    Airplaneoffice airplaneoffice_id;
    public Airplane(){

    }

    public Airplane(String name, int max, boolean status){
        this.name = name;
        this.max_plane_seat = max;;
        this.air_Navigation_Status = status;
    }
    public boolean getAir_Navigation_Status(){
        return this.air_Navigation_Status;
    }


}


