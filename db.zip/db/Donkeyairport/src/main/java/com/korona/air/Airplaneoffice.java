package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "OFFICE")
@Getter @Setter
public class Airplaneoffice implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = AUTO)
    
    @Column(name = "ID", /* unique = true, */ nullable = false)
    private Integer airplane_office_id;
    @Column(name = "NAME")
    private String airplane_office_name;

    @OneToMany(mappedBy = "airplaneoffice_id", fetch=FetchType.LAZY)
    Set<Airplane> Airplane_id = new HashSet<Airplane>();

    @OneToMany(mappedBy = "airplaneoffice_id",  fetch=FetchType.LAZY)
    Set<Flight> Flight_patial = new HashSet<Flight>(0);


    @OneToMany(
        mappedBy = "Airplaneoffice",
        cascade = CascadeType.ALL, orphanRemoval = true, fetch=FetchType.LAZY
    )
    Set<Reservation> reservation_info = new HashSet<Reservation>(0);

    public Airplaneoffice(){

    }
    
    public Airplaneoffice(String name){
        this.airplane_office_name = name;
    }



}


