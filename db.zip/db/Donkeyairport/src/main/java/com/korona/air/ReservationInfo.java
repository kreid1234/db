package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "ReservationInfo")
@Getter @Setter
public class ReservationInfo implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = AUTO)
    @Column(name = "ID", /* unique = true, */ nullable = false)
    private Integer info_id;
    @Column(name = "SEAT_NUMBER")
    private Integer seat_number;
    @Column(name = "SEATE_CAPACITY")
    private Integer seatingcapacity;

    @ManyToOne (fetch=FetchType.LAZY)
    @JoinColumn(name = "AIREPLANE_ID")
    private Airplane airplane_id;

    @ManyToOne (fetch=FetchType.LAZY)
    @JoinColumn(name = "PARTIAL_NAME")
    private Flight partial_name;

    @OneToMany(
        mappedBy = "Reservation",
        cascade = CascadeType.ALL, orphanRemoval = true,
        fetch=FetchType.LAZY
    )
    Set<Reservation> reservation_info = new HashSet<Reservation>(0);
    public ReservationInfo(){

    }
    public ReservationInfo(Integer capacity){
        this.seatingcapacity = capacity;
    }
    
}

