
package com.korona.air;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.AUTO;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "CUSTOMER")
@Getter @Setter
public class Customer implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = AUTO)
    @Column(name = "ID", nullable = false)
    private Integer customer_id;
    @Column(name = "PASSWORD", nullable = false)
    private String password;
    @Column(name = "NAME", nullable = false)
    private String name;
    @Column(name = "RATE")
    private String rate;
    @Column(name = "ADDRESS")
    private String address;
    @Column(name = "CUSTOMER_RRNUM")
    private String rrnum;
    
    @OneToMany(
        mappedBy = "Customer",
        cascade = CascadeType.ALL, orphanRemoval = true, fetch=FetchType.LAZY
    )
    Set<Reservation> reservation_info = new HashSet<Reservation>(0);
    public Customer(){
    }
    public Customer(String password, String name, String rate, String address, String rrnum){
        this.password = password;
        this.name = name;
        this.rate = rate;
        this.address = address;
        this.rrnum = rrnum;
    }
}


