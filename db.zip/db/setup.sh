#!/bin/bash

for H in [0-9][0-9]*-*
do
    echo cp hibernate.properties $H/src/main/resources
    cp hibernate.properties $H/src/main/resources
done

